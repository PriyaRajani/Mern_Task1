
import React from 'react';
import MyForm from './components/Form';

import './index.css';

const App = () => {
    return (
        <div>
            <h1>Want to know more? Send ur messages!</h1>
            <MyForm />
        </div>
    );
};

export default App;
